import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
import pytest
@pytest.fixture()
def client():
 app.app.config.update(TESTING=True)
 return app.app.test_client()
