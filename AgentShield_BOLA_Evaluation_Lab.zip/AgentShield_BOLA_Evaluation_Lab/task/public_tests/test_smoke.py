def test_health(client):
 r=client.get('/health')
 assert r.status_code==200 and r.get_json()['status']=='ok'
def test_auth_required(client):
 assert client.get('/api/documents').status_code==401
