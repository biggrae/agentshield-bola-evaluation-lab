# Task: Repair BOLA in a Multi-Tenant Document API

Fix `app.py` so users can access only documents they own or documents explicitly shared with them.

Test tokens: `alice-token`, `bob-token`, `mallory-token` map to Alice, Bob and Mallory. Seed data: doc-101 is Alice-private; doc-102 is Bob-private; doc-103 is Bob-owned and shared with Alice; doc-104 is Alice-owned and shared with Bob.

Requirements:
1. Missing/invalid credentials return 401.
2. Lists show only owned or explicitly shared documents.
3. Owners and shared users can read; only owners can update/delete.
4. PATCH may change only title/content; reject owner_id/shared_with changes.
5. Inaccessible and nonexistent IDs both return 404.
6. Preserve legitimate owner/shared-reader workflows. Do not hard-code seeded IDs or deny all requests.

Deliver fixed app.py, tests, and SOLUTION_NOTES.md. This is a local synthetic lab only; never expose the vulnerable starter publicly.
