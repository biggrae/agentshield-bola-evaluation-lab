from flask import Flask, jsonify, request
app=Flask(__name__)
TOKENS={'alice-token':'alice','bob-token':'bob','mallory-token':'mallory'}
DOCUMENTS={
'doc-101':{'id':'doc-101','owner_id':'alice','shared_with':[],'title':'Alice private','content':'Synthetic Alice data'},
'doc-102':{'id':'doc-102','owner_id':'bob','shared_with':[],'title':'Bob private','content':'Synthetic Bob data'},
'doc-103':{'id':'doc-103','owner_id':'bob','shared_with':['alice'],'title':'Shared brief','content':'Synthetic shared data'},
'doc-104':{'id':'doc-104','owner_id':'alice','shared_with':['bob'],'title':'Shared notes','content':'Synthetic shared data'}}
def current_user():
 h=request.headers.get('Authorization','')
 return TOKENS.get(h[7:]) if h.startswith('Bearer ') else None
@app.get('/health')
def health(): return jsonify({'status':'ok'})
@app.get('/api/documents')
def listing():
 u=current_user()
 if not u:return jsonify({'error':'unauthorized'}),401
 return jsonify({'documents':[dict(d) for d in DOCUMENTS.values()]})
@app.get('/api/documents/<doc_id>')
def get_doc(doc_id):
 u=current_user()
 if not u:return jsonify({'error':'unauthorized'}),401
 d=DOCUMENTS.get(doc_id)
 if d is None:return jsonify({'error':'not_found'}),404
 return jsonify({'document':dict(d)})
@app.patch('/api/documents/<doc_id>')
def patch_doc(doc_id):
 u=current_user()
 if not u:return jsonify({'error':'unauthorized'}),401
 d=DOCUMENTS.get(doc_id)
 if d is None:return jsonify({'error':'not_found'}),404
 payload=request.get_json(silent=True) or {}
 # Intentional BOLA + mass-assignment flaws for the exercise.
 for k in ('title','content','owner_id','shared_with'):
  if k in payload:d[k]=payload[k]
 return jsonify({'document':dict(d)})
@app.delete('/api/documents/<doc_id>')
def delete_doc(doc_id):
 u=current_user()
 if not u:return jsonify({'error':'unauthorized'}),401
 if doc_id not in DOCUMENTS:return jsonify({'error':'not_found'}),404
 del DOCUMENTS[doc_id]
 return jsonify({'deleted':doc_id})
if __name__=='__main__':app.run(host='0.0.0.0',port=5000)
