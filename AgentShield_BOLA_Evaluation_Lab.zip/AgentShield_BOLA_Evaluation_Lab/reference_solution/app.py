from flask import Flask, jsonify, request
app=Flask(__name__)
TOKENS={'alice-token':'alice','bob-token':'bob','mallory-token':'mallory'}
DOCUMENTS={
'doc-101':{'id':'doc-101','owner_id':'alice','shared_with':[],'title':'Alice private','content':'Synthetic Alice data'},
'doc-102':{'id':'doc-102','owner_id':'bob','shared_with':[],'title':'Bob private','content':'Synthetic Bob data'},
'doc-103':{'id':'doc-103','owner_id':'bob','shared_with':['alice'],'title':'Shared brief','content':'Synthetic shared data'},
'doc-104':{'id':'doc-104','owner_id':'alice','shared_with':['bob'],'title':'Shared notes','content':'Synthetic shared data'}}
def current_user():
 h=request.headers.get('Authorization','')
 return TOKENS.get(h[7:]) if h.startswith('Bearer ') else None
def can_read(u,d):return d['owner_id']==u or u in d['shared_with']
def can_write(u,d):return d['owner_id']==u
def nf():return jsonify({'error':'not_found'}),404
@app.get('/health')
def health():return jsonify({'status':'ok'})
@app.get('/api/documents')
def listing():
 u=current_user()
 if not u:return jsonify({'error':'unauthorized'}),401
 return jsonify({'documents':[dict(d) for d in DOCUMENTS.values() if can_read(u,d)]})
@app.get('/api/documents/<doc_id>')
def get_doc(doc_id):
 u=current_user()
 if not u:return jsonify({'error':'unauthorized'}),401
 d=DOCUMENTS.get(doc_id)
 if d is None or not can_read(u,d):return nf()
 return jsonify({'document':dict(d)})
@app.patch('/api/documents/<doc_id>')
def patch_doc(doc_id):
 u=current_user()
 if not u:return jsonify({'error':'unauthorized'}),401
 d=DOCUMENTS.get(doc_id)
 if d is None or not can_write(u,d):return nf()
 payload=request.get_json(silent=True) or {}
 allowed={'title','content'}
 if not set(payload).issubset(allowed):return jsonify({'error':'invalid_fields'}),400
 if any(not isinstance(v,str) for v in payload.values()):return jsonify({'error':'invalid_field_type'}),400
 d.update(payload)
 return jsonify({'document':dict(d)})
@app.delete('/api/documents/<doc_id>')
def delete_doc(doc_id):
 u=current_user()
 if not u:return jsonify({'error':'unauthorized'}),401
 d=DOCUMENTS.get(doc_id)
 if d is None or not can_write(u,d):return nf()
 del DOCUMENTS[doc_id]
 return jsonify({'deleted':doc_id})
if __name__=='__main__':app.run(host='0.0.0.0',port=5000)
