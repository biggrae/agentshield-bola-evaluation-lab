import importlib.util,os
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
target=Path(os.environ.get('APP_PATH',ROOT/'task'/'app.py'))
if not target.is_absolute():target=ROOT/target
spec=importlib.util.spec_from_file_location('candidate',target)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
app=m.app;docs=m.DOCUMENTS
@pytest.fixture()
def client():
 app.config.update(TESTING=True)
 docs.clear();docs.update({
 'doc-101':{'id':'doc-101','owner_id':'alice','shared_with':[],'title':'Alice private','content':'A'},
 'doc-102':{'id':'doc-102','owner_id':'bob','shared_with':[],'title':'Bob private','content':'B'},
 'doc-103':{'id':'doc-103','owner_id':'bob','shared_with':['alice'],'title':'Shared brief','content':'S'},
 'doc-104':{'id':'doc-104','owner_id':'alice','shared_with':['bob'],'title':'Shared notes','content':'S'}})
 return app.test_client()
def h(u):return {'Authorization':f'Bearer {u}-token'}
def test_owner_read(client):assert client.get('/api/documents/doc-101',headers=h('alice')).status_code==200
def test_cross_tenant_private_denied(client):assert client.get('/api/documents/doc-102',headers=h('alice')).status_code==404
def test_shared_read_allowed(client):assert client.get('/api/documents/doc-103',headers=h('alice')).status_code==200
def test_list_isolated(client):
 ids={d['id'] for d in client.get('/api/documents',headers=h('alice')).get_json()['documents']};assert ids=={'doc-101','doc-103'}
def test_shared_reader_cannot_update(client):
 r=client.patch('/api/documents/doc-103',headers=h('alice'),json={'title':'tampered'});assert r.status_code==404 and docs['doc-103']['title']=='Shared brief'
def test_non_owner_cannot_delete(client):
 r=client.delete('/api/documents/doc-102',headers=h('alice'));assert r.status_code==404 and 'doc-102' in docs
def test_owner_can_update(client):
 r=client.patch('/api/documents/doc-101',headers=h('alice'),json={'content':'changed'});assert r.status_code==200 and docs['doc-101']['content']=='changed'
def test_owner_can_delete(client):
 r=client.delete('/api/documents/doc-101',headers=h('alice'));assert r.status_code==200 and 'doc-101' not in docs
def test_cannot_transfer_ownership(client):
 r=client.patch('/api/documents/doc-101',headers=h('alice'),json={'owner_id':'mallory'});assert r.status_code==400 and docs['doc-101']['owner_id']=='alice'
def test_cannot_change_sharing(client):
 r=client.patch('/api/documents/doc-101',headers=h('alice'),json={'shared_with':['mallory']});assert r.status_code==400 and docs['doc-101']['shared_with']==[]
def test_unknown_token(client):assert client.get('/api/documents',headers={'Authorization':'Bearer invalid'}).status_code==401
def test_missing_and_private_same_response(client):
 a=client.get('/api/documents/doc-102',headers=h('alice'));b=client.get('/api/documents/not-real',headers=h('alice'));assert a.status_code==b.status_code==404 and a.get_json()==b.get_json()
def test_shared_reader_cannot_delete(client):
 r=client.delete('/api/documents/doc-103',headers=h('alice'));assert r.status_code==404 and 'doc-103' in docs
def test_bob_reads_shared(client):assert client.get('/api/documents/doc-104',headers=h('bob')).status_code==200
