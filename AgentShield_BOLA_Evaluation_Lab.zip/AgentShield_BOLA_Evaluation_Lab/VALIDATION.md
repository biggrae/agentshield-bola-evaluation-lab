# Validation status

Python syntax compilation succeeded for the starter app, reference solution, public tests and evaluator tests.

Runtime tests were **not executed in the build environment** because Flask is not installed there and package installation was unavailable. To complete runtime validation on your machine:

```bash
python -m pip install -r task/requirements.txt
PYTHONPATH=task pytest -q task/public_tests
APP_PATH=reference_solution/app.py pytest -q evaluator
```

Do not describe the runtime suite as passing until you run these commands and confirm the results. The vulnerable starter is intentionally expected to fail evaluator authorization checks.
