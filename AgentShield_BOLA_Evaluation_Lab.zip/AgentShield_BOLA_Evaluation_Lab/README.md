# AgentShield — BOLA Evaluation Lab

A local-only portfolio project: repair Broken Object Level Authorization in a synthetic multi-tenant Flask API.

- `task/`: vulnerable starter, task brief, Docker setup and public smoke tests.
- `evaluator/`: separate evaluator tests.
- `reference_solution/`: secure reference implementation.
- Synthetic data only. Do not expose the vulnerable starter publicly.

Install: `pip install -r task/requirements.txt`

Public smoke tests: `PYTHONPATH=task pytest -q task/public_tests`

Reference validation: `APP_PATH=reference_solution/app.py pytest -q evaluator`

The evaluator is visible here for portfolio review. In a production benchmark, keep hidden tests outside the agent workspace.
